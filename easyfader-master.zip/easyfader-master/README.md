# EasyFader - An Ultralight Fading Slideshow for Responsive Layouts

### What Is EasyFader?

EasyFader was created as part of [this tutorial](http://www.barrelny.com/blog/building-a-jquery-slideshow-plugin-from-scratch) on creating a lightweight jQuery plugin from scratch.

This repository is not currently being maintained.
